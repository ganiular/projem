from django.apps import AppConfig


class MilestoneuserConfig(AppConfig):
    name = 'MilestoneUser'
