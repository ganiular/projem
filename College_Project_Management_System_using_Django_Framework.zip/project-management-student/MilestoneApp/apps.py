from django.apps import AppConfig


class MilestoneappConfig(AppConfig):
    name = 'MilestoneApp'
